package com.example.dialastocktaker.ui.dashboard

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.dialastocktaker.R
import com.example.dialastocktaker.databinding.ActivityAdminDashboardBinding
import com.example.dialastocktaker.ui.admin.AdminHomeFragment
import com.example.dialastocktaker.ui.admin.AdminJobsFragment
import com.example.dialastocktaker.ui.admin.AdminMessagesFragment
import com.example.dialastocktaker.ui.admin.AdminReportsFragment
import com.example.dialastocktaker.ui.admin.AdminUsersFragment
import com.example.dialastocktaker.ui.auth.LoginActivity

class AdminDashboardActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAdminDashboardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupNavigation()

        // Default fragment
        if (savedInstanceState == null) {
            loadFragment(AdminHomeFragment())
            binding.navView.selectedItemId = R.id.nav_home
        }
    }

    private fun setupNavigation() {
        binding.navView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> loadFragment(AdminHomeFragment())
                R.id.nav_users -> loadFragment(AdminUsersFragment())
                R.id.nav_jobs -> loadFragment(AdminJobsFragment())
                R.id.nav_messages -> loadFragment(AdminMessagesFragment())
                R.id.nav_reports -> loadFragment(AdminReportsFragment())
                else -> false
            }
        }

        binding.btnLogout.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    private fun loadFragment(fragment: Fragment): Boolean {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
        return true
    }
}
