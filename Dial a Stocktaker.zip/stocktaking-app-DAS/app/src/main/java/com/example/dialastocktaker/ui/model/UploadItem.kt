package com.example.dialastocktaker.ui.model

import java.util.Date

data class UploadItem(
    val id: String,
    val jobId: String,
    val location: String,
    val timestamp: Date,
    val itemCount: Int,
    val status: String
)
