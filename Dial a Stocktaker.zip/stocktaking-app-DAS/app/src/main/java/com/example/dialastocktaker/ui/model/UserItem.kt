package com.example.dialastocktaker.ui.model

data class UserItem(
    val id: Long,
    val name: String,
    val role: String,
    val contactNumber: String,
    val loginCode: String,
    val status: String
)
