package com.example.dialastocktaker.ui.model

import java.util.Date

data class MessageItem(
    val id: Long,
    val senderId: Long,
    val senderName: String,
    val receiverId: Long,
    val receiverName: String,
    val content: String,
    val timestamp: Date,
    val isFromCurrentUser: Boolean
)
